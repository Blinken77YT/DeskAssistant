from deskAssistant.deskAssistant import speak
from deskAssistant.deskAssistant import tellTime
from deskAssistant.deskAssistant import openMail
from deskAssistant.deskAssistant import tellDay
from deskAssistant.deskAssistant import takeCommand
from deskAssistant.deskAssistant import calculate
from deskAssistant.deskAssistant import voiceCalc